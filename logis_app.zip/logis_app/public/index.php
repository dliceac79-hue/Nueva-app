<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/db.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/helpers.php';

require_login();
$page = $_GET['p'] ?? 'dashboard';
$allowed=[
  'dashboard',
  'clients','clients_new','clients_edit',
  'providers','providers_new','providers_edit', 'providers_statement','vendor_bills',
  'invoices','invoices_new','invoices_edit','invoices_view',
  'invoice_items_new','invoice_items_edit',
  'shipments','shipments_new','shipments_edit','shipment_view','vendor_bill_new','vendor_bill_edit',
  'vendor_bill_view','shipment_services_edit','shipment_services_new','shipment_profit',
  'summary',                // si usas el summary genérico
  'financial_summary',      // <-- agrega esta
  'client_statement'  /* estado de cuenta cliente */, 
  'financial_snapshot_list','bank_snapshot_new','financial_snapshot_new',
  'bank_accounts'
];
if(!in_array($page,$allowed,true)) $page='dashboard';

include __DIR__ . '/../app/layout/header.php';
include __DIR__ . "/pages/$page.php";
include __DIR__ . '/../app/layout/footer.php';
