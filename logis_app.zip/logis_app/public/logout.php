<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
logout();
header('Location: '.BASE_URL.'public/login.php'); exit;
