<?php
require_once __DIR__ . '/../../app/db.php';
$pdo = db();
$id = (int)($_GET['id'] ?? 0);
if ($id<=0) die('Falta ?id');
$st = $pdo->prepare("SELECT s.*, c.name AS client_name FROM shipments s
                     LEFT JOIN clients c ON c.client_id=s.client_id
                     WHERE s.shipment_id=?");
$st->execute([$id]);
$r = $st->fetch(PDO::FETCH_ASSOC);
?>
<h2>Embarque #<?= (int)$r['shipment_id'] ?></h2>
<p><strong>Cliente:</strong> <?= htmlspecialchars($r['client_name']) ?></p>
<p><strong>Referencia:</strong> <?= htmlspecialchars($r['reference']) ?></p>
<p><strong>Origen:</strong> <?= htmlspecialchars($r['origin']) ?></p>
<p><strong>Destino:</strong> <?= htmlspecialchars($r['destination']) ?></p>
<p><strong>Recolección:</strong> <?= htmlspecialchars($r['pickup_date']) ?> |
<strong>Entrega:</strong> <?= htmlspecialchars($r['delivery_date']) ?></p>
<p><strong>Status:</strong> <?= htmlspecialchars($r['status']) ?></p>
<p><strong>Costo:</strong> <?= number_format((float)$r['cost'],2) ?></p>
<p><strong>Notas:</strong> <?= nl2br(htmlspecialchars($r['notes'])) ?></p>
<p>
  <a href="<?= BASE_URL ?>public/pages/shipments_edit.php?id=<?= (int)$r['shipment_id'] ?>">Editar</a> |
  <a href="<?= BASE_URL ?>public/pages/shipments.php">Volver</a>
</p>
