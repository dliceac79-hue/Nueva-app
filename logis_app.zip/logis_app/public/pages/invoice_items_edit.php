<?php csrf_validate(); $pdo=db(); $id=(int)($_GET['id']??0); if(!$id){ header('Location: '.BASE_URL.'public/index.php?p=invoices'); exit; }
$st=$pdo->prepare("SELECT * FROM invoice_items WHERE invoice_item_id=?"); $st->execute([$id]); $row=$st->fetch(); if(!$row){ header('Location: '.BASE_URL.'public/index.php?p=invoices'); exit; }
$ships=$pdo->query("SELECT shipment_id, reference FROM shipments ORDER BY shipment_id DESC LIMIT 500")->fetchAll();
$ok=''; $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $shipment_id=(int)($_POST['shipment_id']??0) ?: null; $desc=trim($_POST['description']??''); $qty=$_POST['qty']??1; $unit=$_POST['unit']??''; $price=$_POST['unit_price']??0; $cur=$_POST['currency']??'MXN';
  if($desc===''){ $err='La descripción es obligatoria.'; }
  if(!$err){
    $pdo->prepare("UPDATE invoice_items SET shipment_id=?, description=?, qty=?, unit=?, unit_price=?, currency=? WHERE invoice_item_id=?")
        ->execute([$shipment_id,$desc,$qty,$unit,$price,$cur,$id]);
    header('Location: '.BASE_URL.'public/index.php?p=invoices_edit&id='.(int)$row['invoice_id']); exit;
  }
}
?>
<h1 class="page-title mb-3">Editar concepto #<?= (int)$row['invoice_item_id'] ?></h1>
<?php if($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; if($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<form method="post" class="card p-4"><?php csrf_field(); ?>
  <div class="row g-3">
    <div class="col-md-8"><label class="form-label">Descripción*</label><input class="form-control" name="description" value="<?= e($row['description']) ?>" required></div>
    <div class="col-md-4"><label class="form-label">Embarque</label>
      <select class="form-select" name="shipment_id"><option value="">-- (opcional) --</option>
        <?php foreach($ships as $s): ?><option value="<?= (int)$s['shipment_id'] ?>" <?php if($row['shipment_id']==$s['shipment_id']) echo 'selected'; ?>>#<?= (int)$s['shipment_id'] ?> — <?= e($s['reference']) ?></option><?php endforeach; ?>
      </select></div>
    <div class="col-md-2"><label class="form-label">Cantidad</label><input class="form-control" type="number" step="0.001" name="qty" value="<?= e($row['qty']) ?>"></div>
    <div class="col-md-2"><label class="form-label">Unidad</label><input class="form-control" name="unit" value="<?= e($row['unit']) ?>"></div>
    <div class="col-md-3"><label class="form-label">Precio</label><input class="form-control" type="number" step="0.01" name="unit_price" value="<?= e($row['unit_price']) ?>"></div>
    <div class="col-md-2"><label class="form-label">Moneda</label><input class="form-control" name="currency" value="<?= e($row['currency']) ?>"></div>
  </div>
  <div class="mt-3"><button class="btn btn-primary">Guardar</button> <a class="btn btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=invoices_edit&id=<?= (int)$row['invoice_id'] ?>">Volver</a></div>
</form>
