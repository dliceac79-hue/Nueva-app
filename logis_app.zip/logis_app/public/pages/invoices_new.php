<?php csrf_validate(); $pdo=db(); $ok=''; $err='';
$clients=$pdo->query("SELECT client_id,name FROM clients ORDER BY name")->fetchAll();
if($_SERVER['REQUEST_METHOD']==='POST'){
  $client_id=(int)($_POST['client_id']??0); $number=trim($_POST['invoice_number']??''); $issue=$_POST['issue_date']??null; $due=$_POST['due_date']??null;
  $currency=$_POST['currency']??'MXN'; $subtotal=$_POST['subtotal']??0; $tax=$_POST['tax']??0; $total=$_POST['total']??0; $status=$_POST['status']??'draft'; $notes=$_POST['notes']??'';
  if(!$client_id||$number===''){ $err='Cliente y número de factura son obligatorios.'; }
  if(!$err){
    $pdo->prepare("INSERT INTO invoices(client_id,invoice_number,issue_date,due_date,currency,subtotal,tax,total,status,notes) VALUES(?,?,?,?,?,?,?,?,?,?)")
        ->execute([$client_id,$number,$issue,$due,$currency,$subtotal,$tax,$total,$status,$notes]);
    $ok='Factura creada.';
  }
}
?>
<h1 class="page-title mb-3">Nueva factura</h1>
<?php if($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; if($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<form method="post" class="card p-4"><?php csrf_field(); ?>
  <div class="row g-3">
    <div class="col-md-5"><label class="form-label">Cliente*</label>
      <select class="form-select" name="client_id" required><option value="">-- seleccionar --</option>
      <?php foreach($clients as $c): ?><option value="<?= (int)$c['client_id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?>
      </select></div>
    <div class="col-md-3"><label class="form-label">No. Factura*</label><input class="form-control" name="invoice_number" required></div>
    <div class="col-md-2"><label class="form-label">Fecha</label><input class="form-control" type="date" name="issue_date"></div>
    <div class="col-md-2"><label class="form-label">Vencimiento</label><input class="form-control" type="date" name="due_date"></div>
    <div class="col-md-2"><label class="form-label">Moneda</label><input class="form-control" name="currency" value="MXN"></div>
    <div class="col-md-3"><label class="form-label">Subtotal</label><input class="form-control" type="number" step="0.01" name="subtotal"></div>
    <div class="col-md-3"><label class="form-label">Impuestos</label><input class="form-control" type="number" step="0.01" name="tax"></div>
    <div class="col-md-3"><label class="form-label">Total</label><input class="form-control" type="number" step="0.01" name="total"></div>
    <div class="col-md-2"><label class="form-label">Estatus</label><select class="form-select" name="status"><option>draft</option><option>issued</option><option>paid</option><option>cancelled</option></select></div>
    <div class="col-md-12"><label class="form-label">Notas</label><textarea class="form-control" name="notes" rows="2"></textarea></div>
  </div>
  <div class="mt-3 d-flex gap-2"><button class="btn btn-primary">Guardar</button><a class="btn btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=invoices">Volver</a></div>
</form>
