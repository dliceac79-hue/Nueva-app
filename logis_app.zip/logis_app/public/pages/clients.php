<?php
$pdo=db();
$q=trim($_GET['q']??'');
if($q!==''){
  $like="%$q%";
  $st=$pdo->prepare("SELECT * FROM clients WHERE name LIKE ? OR contact_name LIKE ? OR email LIKE ? ORDER BY client_id DESC LIMIT 200");
  $st->execute([$like,$like,$like]); $rows=$st->fetchAll();
}else{
  $rows=$pdo->query("SELECT * FROM clients ORDER BY client_id DESC LIMIT 200")->fetchAll();
}
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="page-title">Clientes</h1>
  <a class="btn btn-primary" href="<?= BASE_URL ?>public/index.php?p=clients_new">+ Nuevo cliente</a>
</div>
<form class="row g-2 mb-3">
  <div class="col-auto"><input class="form-control" name="q" placeholder="Buscar..." value="<?= e($q) ?>"></div>
  <div class="col-auto"><button class="btn btn-outline-secondary">Buscar</button></div>
</form>
<div class="card p-3">
<div class="table-responsive"><table class="table align-middle">
<thead><tr><th>ID</th><th>Nombre</th><th>Contacto</th><th>Teléfono</th><th>Email</th><th>Límite</th><th>Días</th><th></th></tr></thead>
<tbody>
<?php foreach($rows as $r): ?>
<tr>
  <td>#<?= (int)$r['client_id'] ?></td>
  <td><?= e($r['name']) ?></td>
  <td><?= e($r['contact_name']) ?></td>
  <td><?= e($r['phone']) ?></td>
  <td><?= e($r['email']) ?></td>
  <td style="text-align:right;"><?= number_format((float)($r['credit_limit'] ?? 0),2) ?></td>
  <td style="text-align:center;"><?= (int)($r['credit_days'] ?? 0) ?></td>
  <td>
    <a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=clients_edit&id=<?= (int)$r['client_id'] ?>">Editar</a>
    <a class="btn btn-sm btn-outline-primary" href="<?= BASE_URL ?>public/index.php?p=client_statement&client_id=<?= (int)$r['client_id'] ?>">Estado de cuenta</a>
  </td>
</tr>
<?php endforeach; if(!$rows): ?><tr><td colspan="8" class="text-center text-muted">Sin clientes.</td></tr><?php endif; ?>
</tbody></table></div></div>
