<?php
// public/pages/financial_summary.php
require_once __DIR__.'/../../app/config.php';
require_once __DIR__.'/../../app/db.php';
require_once __DIR__.'/../../app/auth.php';
require_once __DIR__.'/../../app/helpers.php';
require_login();

$pdo = db();
if (!function_exists('h')) { function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); } }

/* ========= Parámetros / Filtros ========= */
$today = new DateTime('today');
$default_from = (clone $today)->modify('-90 days')->format('Y-m-d');
$default_to   = $today->format('Y-m-d');

$from = isset($_GET['from']) && $_GET['from'] !== '' ? $_GET['from'] : $default_from;
$to   = isset($_GET['to'])   && $_GET['to']   !== '' ? $_GET['to']   : $default_to;

$fx_default = defined('APP_USD_MXN') ? (float)APP_USD_MXN : 20.0;
$fx = isset($_GET['fx']) && is_numeric($_GET['fx']) ? (float)$_GET['fx'] : $fx_default;

$fromDate = DateTime::createFromFormat('Y-m-d', $from) ?: new DateTime($default_from);
$toDate   = DateTime::createFromFormat('Y-m-d', $to)   ?: new DateTime($default_to);
$from = $fromDate->format('Y-m-d');
$to   = $toDate->format('Y-m-d');

/* ========= Helpers ========= */
function fetchOneFloat($pdo, $sql, $params = []) { $st=$pdo->prepare($sql); $st->execute($params); $v=$st->fetchColumn(); return $v!==false?(float)$v:0.0; }
function badgeDelta($v){ if ($v === null) return ''; $cls = ($v >= 0) ? 'bg-success' : 'bg-danger'; $sign = ($v >= 0) ? '+' : ''; return '<span class="badge '.$cls.'">'. $sign . number_format($v,2) .'</span>'; }

/* ========= KPIs del periodo (issue_date) ========= */
$kpi_sales = fetchOneFloat($pdo,
  "SELECT COALESCE(SUM(total),0) FROM invoices WHERE issue_date BETWEEN ? AND ? AND LOWER(COALESCE(status,'')) <> 'cancelled'",
  [$from,$to]
);
$kpi_purchases = fetchOneFloat($pdo,
  "SELECT COALESCE(SUM(total),0) FROM vendor_bills WHERE issue_date BETWEEN ? AND ? AND LOWER(COALESCE(status,'')) <> 'cancelled'",
  [$from,$to]
);
$kpi_profit = $kpi_sales - $kpi_purchases;

$paid_clients = fetchOneFloat($pdo, "SELECT COALESCE(SUM(amount_paid),0) FROM invoices WHERE LOWER(COALESCE(status,'')) <> 'cancelled'");
$paid_providers = fetchOneFloat($pdo, "SELECT COALESCE(SUM(amount_paid),0) FROM vendor_bills WHERE LOWER(COALESCE(status,'')) <> 'cancelled'");
$kpi_available = $paid_clients - $paid_providers;

/* ========= AR (Aging) ========= */
$AR_rows = $pdo->query("
  SELECT COALESCE(c.name, CONCAT('Cliente #', i.client_id)) AS cliente,
         COALESCE(NULLIF(i.currency,''),'MXN') AS currency,
         (i.total - i.amount_paid) AS saldo,
         DATEDIFF(CURDATE(), i.due_date) AS days_over
  FROM invoices i
  LEFT JOIN clients c ON c.client_id = i.client_id
  WHERE (i.total - i.amount_paid) > 0 AND LOWER(COALESCE(i.status,'')) NOT IN ('paid','cancelled')
")->fetchAll(PDO::FETCH_ASSOC);
$AR = [];
foreach ($AR_rows as $r) {
  $cliente=(string)$r['cliente']; $curr=(string)$r['currency']; $saldo=(float)$r['saldo']; $d=is_null($r['days_over'])?0:(int)$r['days_over'];
  $AR[$cliente] ??= [];
  $AR[$cliente][$curr] ??= ['currency'=>$curr,'b0_30'=>0,'b31_60'=>0,'b61_90'=>0,'b90'=>0,'total'=>0];
  if ($d <= 0) { $AR[$cliente][$curr]['b0_30'] += $saldo; }
  elseif ($d <= 30) { $AR[$cliente][$curr]['b0_30'] += $saldo; }
  elseif ($d <= 60) { $AR[$cliente][$curr]['b31_60'] += $saldo; }
  elseif ($d <= 90) { $AR[$cliente][$curr]['b61_90'] += $saldo; }
  else { $AR[$cliente][$curr]['b90'] += $saldo; }
  $AR[$cliente][$curr]['total'] += $saldo;
}

/* ========= AP (Aging) ========= */
$has_vb_currency = false;
try { $chk=$pdo->query("SHOW COLUMNS FROM vendor_bills LIKE 'currency'")->fetch(PDO::FETCH_ASSOC); $has_vb_currency=(bool)$chk; } catch(Throwable $e){}
$AP_rows = $pdo->query("
  SELECT COALESCE(p.name, CONCAT('Proveedor #', vb.provider_id)) AS proveedor,
         ".($has_vb_currency ? "COALESCE(NULLIF(vb.currency,''),'MXN')" : "'MXN'")." AS currency,
         (vb.total - vb.amount_paid) AS saldo,
         DATEDIFF(CURDATE(), vb.due_date) AS days_over
  FROM vendor_bills vb
  LEFT JOIN providers p ON p.provider_id = vb.provider_id
  WHERE (vb.total - vb.amount_paid) > 0 AND LOWER(COALESCE(vb.status,'')) NOT IN ('paid','cancelled')
")->fetchAll(PDO::FETCH_ASSOC);
$AP = [];
foreach ($AP_rows as $r) {
  $prov=(string)$r['proveedor']; $curr=(string)$r['currency']; $saldo=(float)$r['saldo']; $d=is_null($r['days_over'])?0:(int)$r['days_over'];
  $AP[$prov] ??= [];
  $AP[$prov][$curr] ??= ['currency'=>$curr,'b0_30'=>0,'b31_60'=>0,'b61_90'=>0,'b90'=>0,'total'=>0];
  if ($d <= 0) { $AP[$prov][$curr]['b0_30'] += $saldo; }
  elseif ($d <= 30) { $AP[$prov][$curr]['b0_30'] += $saldo; }
  elseif ($d <= 60) { $AP[$prov][$curr]['b31_60'] += $saldo; }
  elseif ($d <= 90) { $AP[$prov][$curr]['b61_90'] += $saldo; }
  else { $AP[$prov][$curr]['b90'] += $saldo; }
  $AP[$prov][$curr]['total'] += $saldo;
}

/* ===== Bancos al corte (último snapshot ≤ $to) ===== */
$banks = $pdo->prepare("
  SELECT a.account_id, a.bank_name, a.account_number, a.currency,
         b.snapshot_date, b.balance
  FROM bank_accounts a
  LEFT JOIN bank_balance_snapshots b
    ON b.account_id = a.account_id
   AND b.snapshot_date = (
     SELECT MAX(b2.snapshot_date) FROM bank_balance_snapshots b2
     WHERE b2.account_id=a.account_id AND b2.snapshot_date <= ?
   )
  WHERE a.is_active=1
  ORDER BY a.bank_name
");
$banks->execute([$to]);
$banks = $banks->fetchAll(PDO::FETCH_ASSOC);

$bank_totals = [];
$bank_total_mxn = 0.0;
foreach ($banks as $bk) {
  $cur = $bk['currency'] ?: 'MXN';
  $bal = (float)($bk['balance'] ?? 0);
  $bank_totals[$cur] = ($bank_totals[$cur] ?? 0) + $bal;
  $bank_total_mxn += ($cur==='USD') ? ($bal * $fx) : $bal;
}

/* ===== Totales actuales AR/AP en MXN ===== */
$current_ar_mxn = 0.0;
foreach ($AR as $cliente => $perCurr)
  foreach ($perCurr as $curr => $b)
    $current_ar_mxn += (strtoupper($curr)==='USD') ? ($b['total'] * $fx) : $b['total'];

$current_ap_mxn = 0.0;
foreach ($AP as $prov => $perCurr)
  foreach ($perCurr as $curr => $b)
    $current_ap_mxn += (strtoupper($curr)==='USD') ? ($b['total'] * $fx) : $b['total'];

/* ===== Profit “actual” ===== */
$current_profit_mxn = $bank_total_mxn + $current_ar_mxn - $current_ap_mxn;

/* ===== Último snapshot guardado ===== */
$lastSnap = $pdo->query("
  SELECT snapshot_date, fx_usd_mxn, bank_total_mxn, ar_total_mxn, ap_total_mxn, profit_mxn, notes
  FROM daily_financial_snapshots
  ORDER BY snapshot_date DESC LIMIT 1
")->fetch(PDO::FETCH_ASSOC);

$delta_bank   = $lastSnap ? ($bank_total_mxn      - (float)$lastSnap['bank_total_mxn']) : null;
$delta_ar     = $lastSnap ? ($current_ar_mxn      - (float)$lastSnap['ar_total_mxn'])   : null;
$delta_ap     = $lastSnap ? ($current_ap_mxn      - (float)$lastSnap['ap_total_mxn'])   : null;
$delta_profit = $lastSnap ? ($current_profit_mxn  - (float)$lastSnap['profit_mxn'])     : null;

/* ===== Exportar AR/AP CSV ===== */
if (isset($_GET['export'])) {
  $what = $_GET['export'];
  header('Content-Type: text/csv; charset=utf-8');
  if ($what==='ar') {
    header('Content-Disposition: attachment; filename="cuentas_por_cobrar.csv"');
    $out=fopen('php://output','w'); fputcsv($out,['Cliente','Moneda','0-30','31-60','61-90','90+','Total']);
    foreach($AR as $cliente=>$perCurr) foreach($perCurr as $curr=>$b)
      fputcsv($out,[$cliente,$b['currency'],number_format($b['b0_30'],2,'.',''),number_format($b['b31_60'],2,'.',''),number_format($b['b61_90'],2,'.',''),number_format($b['b90'],2,'.',''),number_format($b['total'],2,'.','')]);
    fclose($out); exit;
  }
  if ($what==='ap') {
    header('Content-Disposition: attachment; filename="cuentas_por_pagar.csv"');
    $out=fopen('php://output','w'); fputcsv($out,['Proveedor','Moneda','0-30','31-60','61-90','90+','Total']);
    foreach($AP as $prov=>$perCurr) foreach($perCurr as $curr=>$b)
      fputcsv($out,[$prov,$b['currency'],number_format($b['b0_30'],2,'.',''),number_format($b['b31_60'],2,'.',''),number_format($b['b61_90'],2,'.',''),number_format($b['b90'],2,'.',''),number_format($b['total'],2,'.','')]);
    fclose($out); exit;
  }
}
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="page-title">Sumario financiero</h1>
</div>

<form class="row g-2 mb-3" method="get" action="">
  <input type="hidden" name="p" value="financial_summary">
  <div class="col-auto">
    <label class="form-label">Desde</label>
    <input type="date" class="form-control" name="from" value="<?= h($from) ?>">
  </div>
  <div class="col-auto">
    <label class="form-label">Hasta</label>
    <input type="date" class="form-control" name="to" value="<?= h($to) ?>">
  </div>
  <div class="col-auto">
    <label class="form-label">Tipo de cambio USD → MXN</label>
    <input type="number" step="0.0001" class="form-control" name="fx" value="<?= h($fx) ?>">
  </div>
  <div class="col-auto align-self-end">
    <button class="btn btn-primary">Aplicar</button>
    <a class="btn btn-light" href="<?= BASE_URL ?>public/index.php?p=financial_summary">Quitar filtros</a>
  </div>
</form>

<!-- KPIs -->
<div class="row g-3">
  <div class="col-lg-3 col-md-6"><div class="card p-3"><div class="text-muted">Ventas (periodo)</div><div class="fs-4 fw-bold">$<?= number_format($kpi_sales,2) ?></div></div></div>
  <div class="col-lg-3 col-md-6"><div class="card p-3"><div class="text-muted">Compras (periodo)</div><div class="fs-4 fw-bold">$<?= number_format($kpi_purchases,2) ?></div></div></div>
  <div class="col-lg-3 col-md-6"><div class="card p-3"><div class="text-muted">Profit (periodo)</div><?php $cls=($kpi_profit>=0?'text-success':'text-danger'); ?><div class="fs-4 fw-bold <?= $cls ?>">$<?= number_format($kpi_profit,2) ?></div></div></div>
  <div class="col-lg-3 col-md-6"><div class="card p-3"><div class="text-muted">Disponible (cobrado − pagado)</div><div class="fs-4 fw-bold">$<?= number_format($kpi_available,2) ?></div></div></div>
</div>

<!-- Bancos al corte -->
<div class="card p-3 mt-3">
  <div class="d-flex justify-content-between align-items-center mb-2">
    <div class="text-muted">Bancos (saldo al corte <?= h($to) ?>)</div>
    <a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=bank_snapshot_new">Capturar corte</a>
  </div>
  <div class="table-responsive">
    <table class="table table-sm align-middle mb-2">
      <thead><tr><th>Banco</th><th>Cuenta</th><th>Moneda</th><th>Fecha corte</th><th class="text-end">Saldo</th></tr></thead>
      <tbody>
        <?php foreach($banks as $bk): ?>
        <tr>
          <td><?= h($bk['bank_name']) ?></td>
          <td><?= h($bk['account_number']) ?></td>
          <td><?= h($bk['currency']) ?></td>
          <td><?= h($bk['snapshot_date'] ?? '—') ?></td>
          <td class="text-end">$<?= number_format((float)($bk['balance'] ?? 0),2) ?></td>
        </tr>
        <?php endforeach; if(!$banks): ?>
        <tr><td colspan="5" class="text-center text-muted">No hay cuentas/saldos.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($banks): ?>
  <div class="row g-2">
    <?php foreach($bank_totals as $cur=>$amt): ?>
      <div class="col-auto">
        <div class="badge bg-light text-dark p-2">Total <?= h($cur) ?>: <strong>$<?= number_format($amt,2) ?></strong></div>
      </div>
    <?php endforeach; ?>
    <div class="col-auto">
      <div class="badge bg-primary p-2">Todo en MXN: <strong>$<?= number_format($bank_total_mxn,2) ?></strong></div>
    </div>
  </div>
  <?php endif; ?>
</div>

<!-- Comparativa vs último corte -->
<div class="card p-3 mt-3">
  <div class="d-flex justify-content-between align-items-center mb-2">
    <div class="text-muted">Comparativa vs último corte<?= $lastSnap ? ' — <strong>'.h($lastSnap['snapshot_date']).'</strong> (FX '.$lastSnap['fx_usd_mxn'].')' : '' ?></div>
    <div class="d-flex gap-2">
      <a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=financial_snapshot_new">Nuevo corte</a>
      <a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=financial_snapshot_list">Historial</a>
    </div>
  </div>
  <?php if(!$lastSnap): ?>
    <div class="alert alert-info mb-0">Aún no hay cortes guardados. Crea uno en “Nuevo corte”.</div>
  <?php else: ?>
  <div class="table-responsive">
    <table class="table table-sm align-middle mb-0">
      <thead><tr><th>Concepto</th><th class="text-end">Actual (<?= h($to) ?>)</th><th class="text-end">Último corte (<?= h($lastSnap['snapshot_date']) ?>)</th><th class="text-end">Δ</th></tr></thead>
      <tbody>
        <tr><td>Bancos (MXN)</td><td class="text-end">$<?= number_format($bank_total_mxn,2) ?></td><td class="text-end">$<?= number_format((float)$lastSnap['bank_total_mxn'],2) ?></td><td class="text-end"><?= badgeDelta($delta_bank) ?></td></tr>
        <tr><td>Cuentas por cobrar (MXN)</td><td class="text-end">$<?= number_format($current_ar_mxn,2) ?></td><td class="text-end">$<?= number_format((float)$lastSnap['ar_total_mxn'],2) ?></td><td class="text-end"><?= badgeDelta($delta_ar) ?></td></tr>
        <tr><td>Cuentas por pagar (MXN)</td><td class="text-end">$<?= number_format($current_ap_mxn,2) ?></td><td class="text-end">$<?= number_format((float)$lastSnap['ap_total_mxn'],2) ?></td><td class="text-end"><?= badgeDelta($delta_ap) ?></td></tr>
        <tr><td><strong>Profit (MXN)</strong></td><td class="text-end"><strong>$<?= number_format($current_profit_mxn,2) ?></strong></td><td class="text-end"><strong>$<?= number_format((float)$lastSnap['profit_mxn'],2) ?></strong></td><td class="text-end"><?= badgeDelta($delta_profit) ?></td></tr>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<!-- AR / AP tablas compactas con export -->
<div class="row g-3 mt-3">
  <div class="col-lg-6">
    <div class="card p-3">
      <div class="d-flex justify-content-between align-items-center mb-2">
        <div class="text-muted">Cuentas por cobrar (Aging por cliente)</div>
        <a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=financial_summary&from=<?= h($from) ?>&to=<?= h($to) ?>&fx=<?= h($fx) ?>&export=ar">Exportar CSV</a>
      </div>
      <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
          <thead><tr><th>Cliente</th><th>Moneda</th><th class="text-end">0–30</th><th class="text-end">31–60</th><th class="text-end">61–90</th><th class="text-end">90+</th><th class="text-end">Total</th></tr></thead>
          <tbody>
          <?php $has=false; foreach($AR as $cliente=>$perCurr): foreach($perCurr as $curr=>$b): $has=true; ?>
            <tr>
              <td><?= h($cliente) ?></td><td><?= h($b['currency']) ?></td>
              <td class="text-end"><?= number_format($b['b0_30'],2) ?></td>
              <td class="text-end"><?= number_format($b['b31_60'],2) ?></td>
              <td class="text-end"><?= number_format($b['b61_90'],2) ?></td>
              <td class="text-end"><?= number_format($b['b90'],2) ?></td>
              <td class="text-end fw-bold"><?= number_format($b['total'],2) ?></td>
            </tr>
          <?php endforeach; endforeach; if(!$has): ?>
            <tr><td colspan="7" class="text-center text-muted">Sin saldos pendientes.</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card p-3">
      <div class="d-flex justify-content-between align-items-center mb-2">
        <div class="text-muted">Cuentas por pagar (Aging por proveedor)</div>
        <a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=financial_summary&from=<?= h($from) ?>&to=<?= h($to) ?>&fx=<?= h($fx) ?>&export=ap">Exportar CSV</a>
      </div>
      <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
          <thead><tr><th>Proveedor</th><th>Moneda</th><th class="text-end">0–30</th><th class="text-end">31–60</th><th class="text-end">61–90</th><th class="text-end">90+</th><th class="text-end">Total</th></tr></thead>
          <tbody>
          <?php $has=false; foreach($AP as $prov=>$perCurr): foreach($perCurr as $curr=>$b): $has=true; ?>
            <tr>
              <td><?= h($prov) ?></td><td><?= h($b['currency']) ?></td>
              <td class="text-end"><?= number_format($b['b0_30'],2) ?></td>
              <td class="text-end"><?= number_format($b['b31_60'],2) ?></td>
              <td class="text-end"><?= number_format($b['b61_90'],2) ?></td>
              <td class="text-end"><?= number_format($b['b90'],2) ?></td>
              <td class="text-end fw-bold"><?= number_format($b['total'],2) ?></td>
            </tr>
          <?php endforeach; endforeach; if(!$has): ?>
            <tr><td colspan="7" class="text-center text-muted">Sin saldos pendientes.</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
