<?php
require_once __DIR__ . '/../../app/credit.php';
$pdo=db();
$client_id = isset($_GET['client_id']) ? (int)$_GET['client_id'] : 0;
if ($client_id <= 0) die("Falta ?client_id=");
$client = credit_get_client($pdo, $client_id);
$data = credit_client_statement($pdo, $client_id);
$rows = $data['rows']; $tot = $data['totals'];
?>
<h2>Estado de cuenta — <?= htmlspecialchars($client['name']) ?></h2>
<p>Límite: <?= number_format($client['credit_limit'],2) ?> |
   Usado: <?= number_format($client['used'],2) ?> |
   Disponible: <strong><?= number_format($client['available'],2) ?></strong> |
   Días de crédito: <?= (int)$client['credit_days'] ?></p>
<div class="card p-3">
<div class="table-responsive">
<table class="table align-middle">
  <thead><tr>
    <th>#</th><th>Emisión</th><th>Vencimiento</th><th>Total</th><th>Pagado</th><th>Saldo</th><th>Status</th>
  </tr></thead>
  <tbody>
  <?php foreach($rows as $r): ?>
  <tr>
    <td><?= htmlspecialchars($r['invoice_number'] ?? $r['invoice_id']) ?></td>
    <td><?= htmlspecialchars($r['issue_date']) ?></td>
    <td><?= htmlspecialchars($r['due_date']) ?></td>
    <td style="text-align:right;"><?= number_format($r['total'],2) ?></td>
    <td style="text-align:right;">&ndash; <?= number_format($r['amount_paid'],2) ?></td>
    <td style="text-align:right;"><?= number_format($r['balance'],2) ?></td>
    <td><?= badge_status($r['status']) ?></td>
  </tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="7" class="text-center text-muted">Sin facturas abiertas.</td></tr><?php endif; ?>
  <tr>
    <th colspan="3" class="text-end">Totales</th>
    <th class="text-end">$<?= number_format($tot['total'],2) ?></th>
    <th class="text-end">$<?= number_format($tot['paid'],2) ?></th>
    <th class="text-end">$<?= number_format($tot['balance'],2) ?></th>
    <th></th>
  </tr>
  </tbody>
</table>
</div>
</div>
<p><a class="btn btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=clients">Volver a clientes</a></p>
