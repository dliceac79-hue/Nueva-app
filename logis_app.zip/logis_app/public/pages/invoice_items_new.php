<?php csrf_validate(); $pdo=db(); $invoice_id=(int)($_GET['invoice_id']??0); if(!$invoice_id){ header('Location: '.BASE_URL.'public/index.php?p=invoices'); exit; }
$ships=$pdo->query("SELECT shipment_id, reference FROM shipments ORDER BY shipment_id DESC LIMIT 500")->fetchAll();
$ok=''; $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $shipment_id=(int)($_POST['shipment_id']??0) ?: null; $desc=trim($_POST['description']??''); $qty=$_POST['qty']??1; $unit=$_POST['unit']??''; $price=$_POST['unit_price']??0; $cur=$_POST['currency']??'MXN';
  if($desc===''){ $err='La descripción es obligatoria.'; }
  if(!$err){
    $pdo->prepare("INSERT INTO invoice_items(invoice_id,shipment_id,description,qty,unit,unit_price,currency) VALUES(?,?,?,?,?,?,?)")
        ->execute([$invoice_id,$shipment_id,$desc,$qty,$unit,$price,$cur]);
    header('Location: '.BASE_URL.'public/index.php?p=invoices_edit&id='.$invoice_id); exit;
  }
}
?>
<h1 class="page-title mb-3">Agregar concepto a Factura #<?= (int)$invoice_id ?></h1>
<?php if($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
<form method="post" class="card p-4"><?php csrf_field(); ?>
  <div class="row g-3">
    <div class="col-md-8"><label class="form-label">Descripción*</label><input class="form-control" name="description" required></div>
    <div class="col-md-4"><label class="form-label">Embarque</label>
      <select class="form-select" name="shipment_id"><option value="">-- (opcional) --</option>
        <?php foreach($ships as $s): ?><option value="<?= (int)$s['shipment_id'] ?>">#<?= (int)$s['shipment_id'] ?> — <?= e($s['reference']) ?></option><?php endforeach; ?>
      </select></div>
    <div class="col-md-2"><label class="form-label">Cantidad</label><input class="form-control" type="number" step="0.001" name="qty" value="1"></div>
    <div class="col-md-2"><label class="form-label">Unidad</label><input class="form-control" name="unit" placeholder="servicio, día, pallet"></div>
    <div class="col-md-3"><label class="form-label">Precio</label><input class="form-control" type="number" step="0.01" name="unit_price"></div>
    <div class="col-md-2"><label class="form-label">Moneda</label><input class="form-control" name="currency" value="MXN"></div>
  </div>
  <div class="mt-3"><button class="btn btn-primary">Guardar</button> <a class="btn btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=invoices_edit&id=<?= (int)$invoice_id ?>">Volver</a></div>
</form>
