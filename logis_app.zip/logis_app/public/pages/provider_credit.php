<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';

/** Helpers to introspect schema (avoid declaring e()). */
function ap_dbname(PDO $pdo): string {
  return (string)$pdo->query('SELECT DATABASE()')->fetchColumn();
}
function ap_table_exists(PDO $pdo, string $table): bool {
  $db = ap_dbname($pdo);
  $st = $pdo->prepare("SELECT 1 FROM information_schema.tables WHERE table_schema=? AND table_name=? LIMIT 1");
  $st->execute([$db, $table]);
  return (bool)$st->fetchColumn();
}
function ap_column_exists(PDO $pdo, string $table, string $column): bool {
  $db = ap_dbname($pdo);
  $st = $pdo->prepare("SELECT 1 FROM information_schema.columns WHERE table_schema=? AND table_name=? AND column_name=? LIMIT 1");
  $st->execute([$db, $table, $column]);
  return (bool)$st->fetchColumn();
}
function ap_pick_col(PDO $pdo, string $table, array $candidates): ?string {
  foreach ($candidates as $c) if (ap_column_exists($pdo, $table, $c)) return $c;
  return null;
}

/** Schema resolution fixed to vendor_bills + providers */
function ap_resolve_schema(PDO $pdo): array {
  $providers_table = 'providers';
  $bills_table     = 'vendor_bills';

  if (!ap_table_exists($pdo, $bills_table)) throw new RuntimeException("No se encontró la tabla '$bills_table'.");
  if (!ap_table_exists($pdo, $providers_table)) throw new RuntimeException("No se encontró la tabla '$providers_table'.");

  $prov_id   = ap_pick_col($pdo, $providers_table, ['provider_id','supplier_id','id_provider','id_supplier','id']);
  $prov_name = ap_pick_col($pdo, $providers_table, ['name','provider_name','supplier_name','razon_social']);
  $prov_cl   = ap_pick_col($pdo, $providers_table, ['credit_limit','limite_credito','limite','creditlimit']);
  $prov_cd   = ap_pick_col($pdo, $providers_table, ['credit_days','dias_credito','dias','creditdays']);
  if (!$prov_id || !$prov_name) throw new RuntimeException("Faltan columnas en '$providers_table'.");

  // vendor_bills columns (incluye posible 'ill_id')
  $bill_id     = ap_pick_col($pdo, $bills_table, ['bill_id','ill_id','vendor_bill_id','id','id_bill']);
  $bill_num    = ap_pick_col($pdo, $bills_table, ['bill_number','folio','invoice_number','reference','num','numero']);
  $bill_pid    = ap_pick_col($pdo, $bills_table, ['provider_id','supplier_id','id_provider','id_supplier','vendor_id']);
  $bill_issue  = ap_pick_col($pdo, $bills_table, ['issue_date','date','fecha_emision','fecha']);
  $bill_due    = ap_pick_col($pdo, $bills_table, ['due_date','vence','fecha_vencimiento']);
  $bill_total  = ap_pick_col($pdo, $bills_table, ['total','importe','monto','amount','grand_total']);
  $bill_paid   = ap_pick_col($pdo, $bills_table, ['amount_paid','pagado','monto_pagado','paid']);
  $bill_status = ap_pick_col($pdo, $bills_table, ['status','estado','estatus']);
  $bill_curr   = ap_pick_col($pdo, $bills_table, ['currency','moneda','divisa']);

  foreach ([[$bill_pid,'FK proveedor'], [$bill_total,'total'], [$bill_status,'status']] as [$c,$label]) {
    if (!$c) throw new RuntimeException("En '$bills_table' falta columna: $label.");
  }
  if (!$bill_id)    $bill_id = 'id';
  if (!$bill_paid)  $bill_paid = null;

  return [
    'providers_table' => $providers_table,
    'bills_table'     => $bills_table,
    'prov' => [
      'id'          => $prov_id,
      'name'        => $prov_name,
      'credit_limit'=> $prov_cl,
      'credit_days' => $prov_cd,
    ],
    'bill' => [
      'id'         => $bill_id,
      'number'     => $bill_num,
      'provider_fk'=> $bill_pid,
      'issue_date' => $bill_issue,
      'due_date'   => $bill_due,
      'total'      => $bill_total,
      'amount_paid'=> $bill_paid,
      'status'     => $bill_status,
      'currency'   => $bill_curr,
    ],
  ];
}

/** Due date helper */
function ap_compute_due_date(?string $issue_date, ?int $credit_days): ?string {
  if (!$issue_date || !$credit_days || $credit_days <= 0) return $issue_date;
  try { $d = new DateTime($issue_date); } catch (Throwable $e) { return $issue_date; }
  $d->modify("+{$credit_days} days");
  return $d->format('Y-m-d');
}

/** Provider summary */
function ap_get_provider(PDO $pdo, int $provider_id): array {
  $S = ap_resolve_schema($pdo);
  $PT = $S['providers_table']; $C = $S['prov'];
  $BT = $S['bills_table'];     $B = $S['bill'];

  $sel = ["{$C['id']} AS provider_id", "{$C['name']} AS name"];
  if ($C['credit_limit']) $sel[] = "{$C['credit_limit']} AS credit_limit";
  if ($C['credit_days'])  $sel[] = "{$C['credit_days']} AS credit_days";

  $sql = "SELECT ".implode(', ',$sel)." FROM {$PT} WHERE {$C['id']}=? LIMIT 1";
  $st = $pdo->prepare($sql);
  $st->execute([$provider_id]);
  $p = $st->fetch(PDO::FETCH_ASSOC);
  if (!$p) throw new RuntimeException("Proveedor no encontrado");

  $paidExpr = $B['amount_paid'] ? "COALESCE({$B['amount_paid']},0)" : "0";
  $q = $pdo->prepare("
    SELECT COALESCE(SUM({$B['total']} - {$paidExpr}),0)
    FROM {$BT}
    WHERE {$B['provider_fk']}=? AND {$B['status']} IN ('open','partial')
  ");
  $q->execute([$provider_id]);
  $used = (float)$q->fetchColumn();

  $limit = (float)($p['credit_limit'] ?? 0);
  $available = max(0.0, $limit - $used);

  return [
    'provider_id'  => (int)$p['provider_id'],
    'name'         => (string)$p['name'],
    'credit_limit' => $limit,
    'credit_days'  => (int)($p['credit_days'] ?? 0),
    'used'         => $used,
    'available'    => $available,
  ];
}

/**
 * Provider statement with optional filters:
 * $opts = ['from'=>Y-m-d|null, 'to'=>Y-m-d|null, 'status'=>string|null, 'currency'=>string|null]
 */
function ap_provider_statement(PDO $pdo, int $provider_id, array $opts=[]): array {
  $S = ap_resolve_schema($pdo);
  $BT = $S['bills_table']; $B = $S['bill'];

  $where = ["{$B['provider_fk']} = :pid"];
  $params = [':pid' => $provider_id];

  if (!empty($opts['from']) && $B['issue_date']) { $where[] = "{$B['issue_date']} >= :from"; $params[':from'] = $opts['from']; }
  if (!empty($opts['to'])   && $B['issue_date']) { $where[] = "{$B['issue_date']} <= :to";   $params[':to']   = $opts['to'];   }

  if (!empty($opts['status']) && strtolower($opts['status']) !== 'all') {
    $where[] = "{$B['status']} = :status";
    $params[':status'] = $opts['status'];
  } else {
    // por defecto mostramos abiertos
    $where[] = "{$B['status']} IN ('open','partial')";
  }

  if (!empty($opts['currency']) && $B['currency']) {
    $where[] = "{$B['currency']} = :ccy";
    $params[':ccy'] = $opts['currency'];
  }

  $paidExpr = $B['amount_paid'] ? "COALESCE({$B['amount_paid']},0)" : "0";
  $orderCols = [];
  if ($B['due_date'])   $orderCols[] = $B['due_date'] . " ASC";
  if ($B['issue_date']) $orderCols[] = $B['issue_date'] . " ASC";
  if (!$orderCols)      $orderCols[] = $B['id'] . " ASC";

  $selects = [
    "{$B['id']} AS bill_id",
    ($B['number'] ? "{$B['number']} AS bill_number" : "NULL AS bill_number"),
    ($B['issue_date'] ? "{$B['issue_date']} AS issue_date" : "NULL AS issue_date"),
    ($B['due_date'] ? "{$B['due_date']} AS due_date" : "NULL AS due_date"),
    "{$B['total']} AS total",
    "{$paidExpr} AS amount_paid",
    "({$B['total']} - {$paidExpr}) AS balance",
    "{$B['status']} AS status",
  ];
  if ($B['currency']) $selects[] = "{$B['currency']} AS currency";

  $sql = "
    SELECT ".implode(', ',$selects)."
    FROM {$BT}
    WHERE ".implode(' AND ', $where)."
    ORDER BY ".implode(', ', $orderCols)."
  ";

  $st = $pdo->prepare($sql);
  $st->execute($params);
  $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

  // Determine credit_days (for computing missing due_date)
  $credit_days = null;
  foreach ($rows as &$r) {
    if (empty($r['due_date']) && !empty($r['issue_date'])) {
      if ($credit_days === null) {
        $PT = $S['providers_table']; $C = $S['prov'];
        if ($C['credit_days']) {
          $st2 = $pdo->prepare("SELECT {$C['credit_days']} FROM {$PT} WHERE {$C['id']}=?");
          $st2->execute([$provider_id]);
          $credit_days = (int)($st2->fetchColumn() ?? 0);
        } else { $credit_days = 0; }
      }
      $r['due_date'] = ap_compute_due_date($r['issue_date'], $credit_days);
    }
  }
  unset($r);

  // Totales
  $tot = ['total'=>0.0,'paid'=>0.0,'balance'=>0.0];
  foreach ($rows as $r) {
    $tot['total']   += (float)$r['total'];
    $tot['paid']    += (float)$r['amount_paid'];
    $tot['balance'] += (float)$r['balance'];
  }

  return ['rows'=>$rows, 'totals'=>$tot];
}

/** Aging buckets as of $as_of (Y-m-d), using due_date or computed */
function ap_provider_aging(PDO $pdo, int $provider_id, ?string $as_of=null): array {
  $as_of_date = $as_of ?: (new DateTime('today'))->format('Y-m-d');
  $data = ap_provider_statement($pdo, $provider_id, ['status'=>'open']); // abiertos por defecto
  $rows = $data['rows'] ?? [];

  // Obtener credit_days para calcular due_date si falta
  $S = ap_resolve_schema($pdo);
  $PT = $S['providers_table']; $C = $S['prov'];
  $credit_days = 0;
  if ($C['credit_days']) {
    $st = $pdo->prepare("SELECT {$C['credit_days']} FROM {$PT} WHERE {$C['id']}=?");
    $st->execute([$provider_id]);
    $credit_days = (int)($st->fetchColumn() ?? 0);
  }

  $buckets = [
    'current' => 0.0,   // no vencido (due_date >= as_of)
    'd0_30'   => 0.0,   // 1-30 días vencido
    'd31_60'  => 0.0,   // 31-60
    'd61_90'  => 0.0,   // 61-90
    'd90p'    => 0.0,   // +90
    'overdue' => 0.0,   // suma de vencidos
    'total'   => 0.0,   // saldo total
  ];

  $asof = new DateTime($as_of_date);
  foreach ($rows as $r) {
    $balance = (float)($r['balance'] ?? 0);
    $due = $r['due_date'] ?? null;
    if (!$due && !empty($r['issue_date'])) {
      $due = ap_compute_due_date($r['issue_date'], $credit_days);
    }
    $buckets['total'] += $balance;
    if (!$due) { $buckets['current'] += $balance; continue; }

    try { $d_due = new DateTime($due); } catch (Throwable $e) { $buckets['current'] += $balance; continue; }
    $diff = (int)$d_due->diff($asof)->format('%r%a'); // días (negativo si no ha vencido)

    if ($diff < 0) {
      $buckets['current'] += $balance;
    } elseif ($diff <= 30) {
      $buckets['d0_30'] += $balance; $buckets['overdue'] += $balance;
    } elseif ($diff <= 60) {
      $buckets['d31_60'] += $balance; $buckets['overdue'] += $balance;
    } elseif ($diff <= 90) {
      $buckets['d61_90'] += $balance; $buckets['overdue'] += $balance;
    } else {
      $buckets['d90p'] += $balance;   $buckets['overdue'] += $balance;
    }
  }
  return $buckets;
}
