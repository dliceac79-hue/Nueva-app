<?php
require_once __DIR__ . '/../../app/db.php';
$pdo = db();
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $st = $pdo->prepare("INSERT INTO shipments (client_id, reference, origin, destination, pickup_date, delivery_date, status, cost, notes)
                       VALUES (?,?,?,?,?,?,?,?,?)");
  $st->execute([
    (int)$_POST['client_id'], $_POST['reference'], $_POST['origin'], $_POST['destination'],
    $_POST['pickup_date'] ?: null, $_POST['delivery_date'] ?: null,
    $_POST['status'] ?? 'draft', (float)($_POST['cost'] ?? 0), $_POST['notes'] ?? null
  ]);
  header("Location: ".BASE_URL."public/pages/shipments.php"); exit;
}
?>
<h2>Nuevo embarque</h2>
<form method="post">
  Cliente (ID): <input type="number" name="client_id" required><br><br>
  Referencia: <input type="text" name="reference" required><br><br>
  Origen: <input type="text" name="origin" required><br><br>
  Destino: <input type="text" name="destination" required><br><br>
  Recolección: <input type="date" name="pickup_date"><br><br>
  Entrega: <input type="date" name="delivery_date"><br><br>
  Status:
  <select name="status">
    <option value="draft">Borrador</option>
    <option value="scheduled">Programado</option>
    <option value="in_transit">En tránsito</option>
    <option value="delivered">Entregado</option>
    <option value="cancelled">Cancelado</option>
  </select><br><br>
  Costo: <input type="number" step="0.01" name="cost"><br><br>
  Notas:<br><textarea name="notes" rows="4" cols="50"></textarea><br><br>
  <button type="submit">Guardar</button>
  <a href="<?= BASE_URL ?>public/pages/shipments.php">Cancelar</a>
</form>
