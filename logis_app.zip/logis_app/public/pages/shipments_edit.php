<?php
require_once __DIR__ . '/../../app/db.php';
$pdo = db();
$id = (int)($_GET['id'] ?? 0);
if ($id<=0) die('Falta ?id');
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $st = $pdo->prepare("UPDATE shipments SET client_id=?, reference=?, origin=?, destination=?,
                       pickup_date=?, delivery_date=?, status=?, cost=?, notes=? WHERE shipment_id=?");
  $st->execute([
    (int)$_POST['client_id'], $_POST['reference'], $_POST['origin'], $_POST['destination'],
    $_POST['pickup_date'] ?: null, $_POST['delivery_date'] ?: null,
    $_POST['status'] ?? 'draft', (float)($_POST['cost'] ?? 0), $_POST['notes'] ?? null, $id
  ]);
  header("Location: ".BASE_URL."public/pages/shipments_view.php?id=".$id); exit;
}
$st = $pdo->prepare("SELECT * FROM shipments WHERE shipment_id=?");
$st->execute([$id]);
$r = $st->fetch(PDO::FETCH_ASSOC);
?>
<h1 class="page-title mb-3">Editar embarque</h1>
<?php if($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; if($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
<form method="post" class="card p-4 mb-4">

<div class="row g-3">
    <div class="col-md-4"><label class="form-label">Cliente*</label>
      <select class="form-select" name="client_id" required>
        <?php foreach($clients as $c): ?><option value="<?= (int)$c['client_id'] ?>" <?php if($row['client_id']==$c['client_id']) echo 'selected'; ?>><?= e($c['name']) ?></option><?php endforeach; ?>
      </select></div>
    <div class="col-md-4"><label class="form-label">Referencia*</label><input class="form-control" name="reference" value="<?= e($row['reference']) ?>" required></div>
    <div class="col-md-4"><label class="form-label">Ref. Cliente</label><input class="form-control" name="customer_ref" value="<?= e($row['customer_ref']) ?>"></div>
    <div class="col-md-3"><label class="form-label">Modo</label><select class="form-select" name="mode"><?php foreach(['ground','air','ocean','rail','multimodal'] as $m): ?><option <?php if($row['mode']===$m) echo 'selected'; ?>><?= e($m) ?></option><?php endforeach; ?></select></div>
    <div class="col-md-3"><label class="form-label">Estatus</label><select class="form-select" name="status"><?php foreach(['draft','booked','in_transit','delivered','cancelled'] as $s): ?><option <?php if($row['status']===$s) echo 'selected'; ?>><?= e($s) ?></option><?php endforeach; ?></select></div>
    <div class="col-md-6"><label class="form-label">Incoterm</label><input class="form-control" name="incoterm" value="<?= e($row['incoterm']) ?>"></div>
    <div class="col-md-4"><label class="form-label">Origen</label><input class="form-control" name="origin" value="<?= e($row['origin']) ?>"></div>
    <div class="col-md-4"><label class="form-label">Estado Origen</label><input class="form-control" name="origin_state" value="<?= e($row['origin_state']) ?>"></div>
    <div class="col-md-4"><label class="form-label">Pa��s Origen</label><input class="form-control" name="origin_country" value="<?= e($row['origin_country']) ?>"></div>
    <div class="col-md-4"><label class="form-label">Destino</label><input class="form-control" name="destination" value="<?= e($row['destination']) ?>"></div>
    <div class="col-md-4"><label class="form-label">Estado Destino</label><input class="form-control" name="destination_state" value="<?= e($row['destination_state']) ?>"></div>
    <div class="col-md-4"><label class="form-label">Pa��s Destino</label><input class="form-control" name="destination_country" value="<?= e($row['destination_country']) ?>"></div>
    <div class="col-md-3"><label class="form-label">Pickup</label><input class="form-control" type="date" name="pickup_date" value="<?= e($row['pickup_date']) ?>"></div>
    <div class="col-md-3"><label class="form-label">Entrega</label><input class="form-control" type="date" name="delivery_date" value="<?= e($row['delivery_date']) ?>"></div>
    <div class="col-md-2"><label class="form-label">Piezas</label><input class="form-control" type="number" name="pieces" value="<?= e($row['pieces']) ?>"></div>
    <div class="col-md-2"><label class="form-label">Peso</label><input class="form-control" type="number" step="0.001" name="weight" value="<?= e($row['weight']) ?>"></div>
    <div class="col-md-2"><label class="form-label">Volumen</label><input class="form-control" type="number" step="0.001" name="volume" value="<?= e($row['volume']) ?>"></div>
    <div class="col-md-12"><label class="form-label">Notas</label><textarea class="form-control" name="notes" rows="2"><?= e($row['notes']) ?></textarea></div>
  </div>
  <div class="mt-3"><button class="btn btn-primary">Guardar</button> <a class="btn btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=shipments">Volver</a></div>
  
</form>


<div class="card p-3">
  <div class="d-flex justify-content-between align-items-center mb-2">
    <h2 class="h6 m-0">Servicios / Costos por proveedor</h2>
    <a class="btn btn-sm btn-primary" href="<?= BASE_URL ?>public/index.php?p=shipment_services_new&shipment_id=<?= (int)$id ?>">+ Agregar servicio</a>
  </div>
  <div class="table-responsive">
    <table class="table align-middle">
      <thead><tr><th>ID</th><th>Proveedor</th><th>Tipo</th><th>Ref.</th><th>Costo</th><th>Estatus</th><th></th></tr></thead>
      <tbody>
      <?php foreach($services as $s): ?>
        <tr>
          <td>#<?= (int)$s['shipment_service_id'] ?></td>
          <td><?= e($s['provider_name']) ?></td>
          <td><?= e($s['service_type']) ?></td>
          <td><?= e($s['service_ref']) ?></td>
          <td><?= e($s['cost_currency']) ?> <?= number_format((float)$s['cost_amount'],2) ?></td>
          <td><?= badge_status($s['status']) ?></td>
          <td><a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=shipment_services_edit&id=<?= (int)$s['shipment_service_id'] ?>">Editar</a></td>
        </tr>
      <?php endforeach; if(!$services): ?><tr><td colspan="7" class="text-center text-muted">Sin servicios a��n.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>