<?php
require_once __DIR__ . '/../../app/db.php';
$pdo = db();
$rows = $pdo->query("SELECT s.*, c.name AS client_name
                     FROM shipments s
                     LEFT JOIN clients c ON c.client_id = s.client_id
                     ORDER BY s.shipment_id DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="page-title">Embarques</h1>
  <a class="btn btn-primary" href="<?= BASE_URL ?>public/index.php?p=shipments_new">+ Nuevo embarque</a>
</div>

<form class="row g-2 mb-3">
  <div class="col-auto"><input class="form-control" type="text" name="q" placeholder="Buscar referencia, cliente, modo o estatus" value="<?= e($q) ?>"></div>
  <div class="col-auto"><button class="btn btn-outline-secondary">Buscar</button></div>
</form>
<div class="card p-3"><div class="table-responsive">
<table class="table align-middle">
  <thead><tr><th>ID</th><th>Referencia</th><th>Cliente</th><th>Modo</th><th>Estatus</th><th>Piezas</th><th>Peso</th><th>Pickup</th><th>Entrega</th><th></th></tr></thead>
  <tbody>
  <?php foreach($rows as $r): ?>
    <tr>
      <td>#<?= (int)$r['shipment_id'] ?></td>
      <td><?= e($r['reference']) ?></td>
      <td><?= e($r['client_name']) ?></td>
      <td><?= e($r['mode']) ?></td>
      <td><?= badge_status($r['status']) ?></td>
      <td><?= e($r['pieces']) ?></td>
      <td><?= e($r['weight']) ?></td>
      <td><?= e($r['pickup_date']) ?></td>
      <td><?= e($r['delivery_date']) ?></td>
      <td><a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=shipments_view&id=<?= (int)$r['shipment_id'] ?>">Ver</a></td>
      <td><a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=shipments_edit&id=<?= (int)$r['shipment_id'] ?>">Editar</a></td>
    </tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="10" class="text-center text-muted">Sin embarques.</td></tr><?php endif; ?>
  </tbody>
</table>
