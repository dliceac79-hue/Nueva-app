<?php
ob_start();
require __DIR__ . '/invoice_view.php';
$html = ob_get_clean();

require_once __DIR__ . '/../../app/services/pdf.php';
if (!try_render_pdf($html, 'factura.pdf')) {
  echo $html; // Fallback: permite "Imprimir → Guardar como PDF"
}
