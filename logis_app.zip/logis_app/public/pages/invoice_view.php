<?php
require_once __DIR__ . '/../../app/db.php';
require_once __DIR__ . '/../../app/branding.php';

$pdo = db();
$invoice_id = (int)($_GET['id'] ?? 0);
if ($invoice_id <= 0) { die('Falta ?id'); }

$inv = $pdo->prepare("SELECT i.*, c.name AS client_name, c.email AS client_email, c.credit_days
                      FROM invoices i
                      LEFT JOIN clients c ON c.client_id = i.client_id
                      WHERE i.invoice_id=?");
$inv->execute([$invoice_id]);
$inv = $inv->fetch(PDO::FETCH_ASSOC);
if (!$inv) { die('Factura no encontrada'); }

$items = [];
try {
  $st = $pdo->prepare("SELECT * FROM invoice_items WHERE invoice_id=? ORDER BY item_id ASC");
  $st->execute([$invoice_id]);
  $items = $st->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $items = []; }

$subtotal = 0; $tax = isset($inv['tax'])?(float)$inv['tax']:0; $total = isset($inv['total'])?(float)$inv['total']:0;
if ($items && $total == 0) {
  foreach($items as $it){
    $qty = isset($it['qty']) ? (float)$it['qty'] : (float)($it['quantity'] ?? 1);
    $unit = isset($it['unit_price']) ? (float)$it['unit_price'] : (float)($it['price'] ?? 0);
    $line = $qty * $unit;
    $subtotal += $line;
  }
  $total = $subtotal + $tax;
}

$issue = htmlspecialchars($inv['issue_date'] ?? '');
$due   = htmlspecialchars($inv['due_date'] ?? '');
$number= htmlspecialchars($inv['invoice_number'] ?? ('#'.$inv['invoice_id']));
$client= htmlspecialchars($inv['client_name'] ?? '');
$addr  = htmlspecialchars($inv['client_address'] ?? '');
$status= htmlspecialchars($inv['status'] ?? 'issued');
$notes = htmlspecialchars($inv['notes'] ?? '');
$currency = htmlspecialchars($inv['currency'] ?? '');
?><!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Factura <?= $number ?> — <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>public/assets/print.css">
</head>
<body class="body-invoice">
  <div class="actions no-print">
    <a href="<?= BASE_URL ?>public/pages/invoice_pdf.php?id=<?= $invoice_id ?>" class="btn">Exportar PDF</a>
    <button onclick="window.print()">Imprimir</button>
    <a href="<?= BASE_URL ?>public/index.php?page=invoices">Volver</a>
  </div>
  <div class="head">
    <div style="display:flex; align-items:center; gap:12px;">
      <img src="<?= APP_LOGO ?>" alt="<?= APP_NAME ?>" style="height:42px">
      <div>
        <h1>Factura <span class="small"><?= $number ?></span></h1>
        <div class="small"><?= APP_NAME ?></div>
      </div>
    </div>
    <div style="text-align:right;">
      <div><strong>Emisión:</strong> <?= $issue ?></div>
      <div><strong>Vencimiento:</strong> <?= $due ?></div>
      <div><span class="badge"><?= strtoupper($status) ?></span></div>
    </div>
  </div>
  <div>
    <strong>Cliente:</strong> <?= $client ?><br>
    <span class="small"><?= $addr ?></span>
  </div>

  <table class="table">
    <tr><th>Descripción</th><th class="right">Cant.</th><th class="right">P. Unit</th><th class="right">Importe</th></tr>
    <?php if ($items): foreach($items as $it):
      $desc = htmlspecialchars($it['description'] ?? ($it['concept'] ?? 'Servicio'));
      $qty  = isset($it['qty']) ? (float)$it['qty'] : (float)($it['quantity'] ?? 1);
      $unit = isset($it['unit_price']) ? (float)$it['unit_price'] : (float)($it['price'] ?? 0);
      $amt  = isset($it['line_total']) ? (float)$it['line_total'] : $qty*$unit;
      $subtotal += $amt;
    ?>
      <tr>
        <td><?= $desc ?></td>
        <td class="right"><?= number_format($qty,2) ?></td>
        <td class="right"><?= number_format($unit,2) ?></td>
        <td class="right"><?= number_format($amt,2) ?></td>
      </tr>
    <?php endforeach; else: ?>
      <tr><td colspan="4" class="small">* Esta factura no tiene partidas capturadas en invoice_items (se mostrará solo el total).</td></tr>
    <?php endif; ?>
    <tr class="total-row"><td colspan="3" class="right">Subtotal</td><td class="right"><?= number_format($subtotal,2) ?></td></tr>
    <tr class="total-row"><td colspan="3" class="right">Impuestos</td><td class="right"><?= number_format($tax,2) ?></td></tr>
    <tr class="total-row"><td colspan="3" class="right">Total</td><td class="right"><?= number_format($total,2) ?></td></tr>
  </table>
  <?php if ($notes): ?><div class="footer-note"><strong>Notas:</strong> <?= $notes ?></div><?php endif; ?>
</body>
</html>
