<?php csrf_validate(); $pdo=db(); $shipment_id=(int)($_GET['shipment_id']??0); if(!$shipment_id){ header('Location: '.BASE_URL.'public/index.php?p=shipments'); exit; }
$providers=$pdo->query("SELECT provider_id,name FROM providers ORDER BY name")->fetchAll();
$ok=''; $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $provider_id=(int)($_POST['provider_id']??0); $type=$_POST['service_type']??''; $ref=$_POST['service_ref']??'';
  $cur=$_POST['cost_currency']??'MXN'; $amt=$_POST['cost_amount']??null; $status=$_POST['status']??'planned'; $notes=$_POST['notes']??'';
  if($type===''){ $err='El tipo de servicio es obligatorio.'; }
  if(!$err){
    $pdo->prepare("INSERT INTO shipment_services(shipment_id,provider_id,service_type,service_ref,cost_currency,cost_amount,status,notes) VALUES(?,?,?,?,?,?,?,?)")
        ->execute([$shipment_id,$provider_id,$type,$ref,$cur,$amt,$status,$notes]);
    header('Location: '.BASE_URL.'public/index.php?p=shipments_edit&id='.$shipment_id); exit;
  }
}
?>
<h1 class="page-title mb-3">Agregar servicio a Embarque #<?= (int)$shipment_id ?></h1>
<?php if($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
<form method="post" class="card p-4"><?php csrf_field(); ?>
  <div class="row g-3">
    <div class="col-md-6"><label class="form-label">Proveedor</label>
      <select class="form-select" name="provider_id"><option value="">-- (opcional) --</option>
        <?php foreach($providers as $p): ?><option value="<?= (int)$p['provider_id'] ?>"><?= e($p['name']) ?></option><?php endforeach; ?>
      </select></div>
    <div class="col-md-3"><label class="form-label">Tipo*</label><input class="form-control" name="service_type" placeholder="drayage, linehaul, almacenaje..." required></div>
    <div class="col-md-3"><label class="form-label">Referencia</label><input class="form-control" name="service_ref" placeholder="BL/AWB/Contenedor/Placa"></div>
    <div class="col-md-2"><label class="form-label">Moneda</label><input class="form-control" name="cost_currency" value="MXN"></div>
    <div class="col-md-2"><label class="form-label">Costo</label><input class="form-control" type="number" step="0.01" name="cost_amount"></div>
    <div class="col-md-3"><label class="form-label">Estatus</label><select class="form-select" name="status"><option>planned</option><option>in_progress</option><option>done</option><option>cancelled</option></select></div>
    <div class="col-md-12"><label class="form-label">Notas</label><textarea class="form-control" name="notes" rows="2"></textarea></div>
  </div>
  <div class="mt-3"><button class="btn btn-primary">Guardar</button> <a class="btn btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=shipments_edit&id=<?= (int)$shipment_id ?>">Volver</a></div>
</form>
