<?php
$pdo=db(); $q=trim($_GET['q']??'');
$where=''; $params=[];
if($q!==''){ $where="WHERE i.invoice_number LIKE ? OR c.name LIKE ? OR i.status LIKE ?"; $like="%$q%"; $params=[$like,$like,$like]; }
$sql="SELECT i.*, c.name client_name FROM invoices i LEFT JOIN clients c ON c.client_id=i.client_id $where ORDER BY i.invoice_id DESC LIMIT 300";
$st=$pdo->prepare($sql); $st->execute($params); $rows=$st->fetchAll();
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="page-title">Facturación</h1>
  <a class="btn btn-primary" href="<?= BASE_URL ?>public/index.php?p=invoices_new">+ Nueva factura</a>
</div>
<form class="row g-2 mb-3">
  <div class="col-auto"><input class="form-control" type="text" name="q" placeholder="No. factura, cliente, estatus" value="<?= e($q) ?>"></div>
  <div class="col-auto"><button class="btn btn-outline-secondary">Buscar</button></div>
</form>
<div class="card p-3"><div class="table-responsive">
<table class="table align-middle">
  <thead><tr><th>ID</th><th>No. Factura</th><th>Cliente</th><th>Fecha</th><th>Total</th><th>Estatus</th><th></th></tr></thead>
  <tbody>
  <?php foreach($rows as $r): ?>
    <tr>
      <td>#<?= (int)$r['invoice_id'] ?></td>
      <td><?= e($r['invoice_number']) ?></td>
      <td><?= e($r['client_name']) ?></td>
      <td><?= e($r['issue_date']) ?></td>
      <td><?= e($r['currency']) ?> <?= number_format((float)$r['total'],2) ?></td>
      <td><?= badge_status($r['status']) ?></td>
      <td><a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>public/index.php?p=invoices_edit&id=<?= (int)$r['invoice_id'] ?>">Abrir</a></td>
    </tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="7" class="text-center text-muted">Sin facturas.</td></tr><?php endif; ?>
  </tbody>
</table>
</div></div>
