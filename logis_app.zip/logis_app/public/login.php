<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/db.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/helpers.php';

if(is_logged_in()){ header('Location: '.BASE_URL.'public/index.php'); exit; }
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $email=trim($_POST['email']??''); $pass=$_POST['password']??'';
  if(!$email||!$pass){ $error='Ingresa correo y contraseña.'; }
  else if(attempt_login($email,$pass)){ header('Location: '.BASE_URL.'public/index.php'); exit; }
  else { $error='Credenciales inválidas.'; }
}
include __DIR__ . '/../app/layout/header.php';
?>
<div class="row justify-content-center">
  <div class="col-md-6 col-lg-5"><div class="card p-4 p-md-5">
    <div class="text-center mb-3">
      <?php require_once __DIR__ . '/../app/branding.php'; ?>
      <img src="<?= APP_LOGO ?>" alt="<?= APP_NAME ?>" style="height:60px" class="mb-2"><br>
      <strong><?= APP_NAME ?></strong>
    </div>
    <h1 class="h4 mb-3">Iniciar sesión</h1>
    <?php if($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
    <form method="post">
      <div class="mb-3"><label class="form-label">Email</label><input class="form-control" type="email" name="email" required></div>
      <div class="mb-3"><label class="form-label">Contraseña</label><input class="form-control" type="password" name="password" required></div>
      <button class="btn btn-primary w-100">Entrar</button>
    </form>
  </div></div>
</div>
<?php include __DIR__ . '/../app/layout/footer.php'; ?>
