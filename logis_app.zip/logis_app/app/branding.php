<?php
// app/branding.php
// Centraliza nombre y logo de la empresa para toda la app.
if (!defined('APP_NAME')) {
  define('APP_NAME', 'Lites Logistics LLC');
}
if (!defined('APP_LOGO')) {
  // Usa el logo de login por ahora (imagen proporcionada)
  define('APP_LOGO', BASE_URL . 'public/assets/logo_login.png');
}
?>
