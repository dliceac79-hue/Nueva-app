<?php
require_once __DIR__ . '/db.php';
if (session_status()===PHP_SESSION_NONE){ session_start(); }

function current_user(){ return $_SESSION['user']??null; }
function is_logged_in(){ return !!current_user(); }
function require_login(){ if(!is_logged_in()){ header('Location: '.BASE_URL.'public/login.php'); exit; } }

function attempt_login($email,$password){
  $email = trim((string)$email);
  $email = preg_replace('/\s+/', '', $email);
  $pdo=db();
  $st=$pdo->prepare("SELECT user_id,name,email,password_hash,role,is_active FROM users WHERE email=? LIMIT 1");
  $st->execute([$email]);
  $u=$st->fetch(PDO::FETCH_ASSOC);
  if($u && (int)$u['is_active']===1 && isset($u['password_hash']) && strlen($u['password_hash'])>=55){
    if(password_verify($password, $u['password_hash'])){
      $_SESSION['user']=['user_id'=>$u['user_id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role']];
      return true;
    }
  }
  return false;
}
function logout(){ session_destroy(); }
