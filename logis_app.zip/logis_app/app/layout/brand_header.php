<?php
require_once __DIR__ . '/../branding.php';
?>
<header class="navbar navbar-light bg-light border-bottom">
  <div class="container-fluid py-2 d-flex align-items-center">
    <img src="<?= APP_LOGO ?>" alt="<?= APP_NAME ?>" style="height:36px;width:auto" class="me-2">
    <strong><?= APP_NAME ?></strong>
  </div>
</header>
