<?php
// app/services/pdf.php
function try_render_pdf($html, $filename = 'document.pdf') {
  if (class_exists('\Dompdf\Dompdf')) {
    $dompdf = new \Dompdf\Dompdf(['isRemoteEnabled' => true]);
    $dompdf->loadHtml($html, 'UTF-8');
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    $dompdf->stream($filename, ['Attachment' => true]);
    return true;
  }
  return false;
}
