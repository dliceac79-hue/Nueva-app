<?php
require_once __DIR__ . '/db.php';

function credit_get_client(PDO $pdo, int $client_id): array {
  $st = $pdo->prepare("SELECT client_id, name, credit_limit, credit_days FROM clients WHERE client_id=?");
  $st->execute([$client_id]);
  $c = $st->fetch(PDO::FETCH_ASSOC);
  if (!$c) throw new RuntimeException("Cliente no encontrado");
  $q = $pdo->prepare("SELECT COALESCE(SUM(total - COALESCE(amount_paid,0)),0) AS used
                      FROM invoices
                      WHERE client_id=? AND status IN ('issued','overdue')");
  $q->execute([$client_id]);
  $used = (float)($q->fetch(PDO::FETCH_ASSOC)['used'] ?? 0);
  $limit = (float)($c['credit_limit'] ?? 0);
  $available = max(0, $limit - $used);
  return [
    'client_id'   => (int)$c['client_id'],
    'name'        => $c['name'],
    'credit_limit'=> $limit,
    'credit_days' => (int)($c['credit_days'] ?? 0),
    'used'        => $used,
    'available'   => $available,
  ];
}

function credit_compute_due_date(string $issue_date, int $credit_days): ?string {
  if(!$issue_date) return null;
  try{ $d=new DateTime($issue_date); } catch(Throwable $e){ return null; }
  if ($credit_days > 0) { $d->modify("+{$credit_days} days"); }
  return $d->format('Y-m-d');
}

function credit_client_statement(PDO $pdo, int $client_id): array {
  $sql = "SELECT invoice_id, invoice_number, issue_date, due_date,
                 total, COALESCE(amount_paid,0) AS amount_paid,
                 (total - COALESCE(amount_paid,0)) AS balance,
                 status
          FROM invoices
          WHERE client_id=? AND status IN ('issued','overdue')
          ORDER BY due_date ASC, issue_date ASC";
  $st = $pdo->prepare($sql);
  $st->execute([$client_id]);
  $rows = $st->fetchAll(PDO::FETCH_ASSOC);
  $tot = ['total'=>0.0,'paid'=>0.0,'balance'=>0.0];
  foreach ($rows as $r) {
    $tot['total']   += (float)$r['total'];
    $tot['paid']    += (float)$r['amount_paid'];
    $tot['balance'] += (float)$r['balance'];
  }
  return ['rows'=>$rows, 'totals'=>$tot];
}

function credit_apply_due_date_on_create(PDO $pdo, int $client_id, string $issue_date): ?string {
  $st = $pdo->prepare("SELECT credit_days FROM clients WHERE client_id=?");
  $st->execute([$client_id]);
  $cd = (int)($st->fetchColumn() ?? 0);
  return credit_compute_due_date($issue_date, $cd);
}
