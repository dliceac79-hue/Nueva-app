<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/db.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/helpers.php';

require_login();
$page = $_GET['p'] ?? 'dashboard';
$allowed=[
  'dashboard',
  'clients','clients_new','clients_edit',
  'providers','providers_new','providers_edit',
  'invoices','invoices_new','invoices_edit',
  'invoice_items_new','invoice_items_edit',
  'shipments','shipments_new','shipments_edit',
  'client_statement'  /* estado de cuenta cliente */
];
if(!in_array($page,$allowed,true)) $page='dashboard';

include __DIR__ . '/../app/layout/header.php';
include __DIR__ . "/pages/$page.php";
include __DIR__ . '/../app/layout/footer.php';
